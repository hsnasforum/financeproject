# News Digest Day

- Date(KST): 2026-03-04
- Generated at: 2026-03-04T11:27:31.261Z
- Observation: 주식시장 관련 이슈 비중이 높아졌고, 관찰 우선순위가 상승했습니다.

## 근거 링크
- https://www.yna.co.kr/view/AKR20260304166800002
- https://www.yna.co.kr/view/AKR20260304167351001
- https://www.yna.co.kr/view/AKR20260304149800002
- https://www.hankyung.com/article/2026030491721
- https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBydEJoYVBHeDFhLVcxZG00NjJVdGJXbUJobWd6X0tidktfVk9mVWljeDdPaGZyZV9VamhZVThIcFV0eFo0aHNJQWpULXF4Vy1lcEY3VnAzaFpvWDFielkyNTl6MWlfVzQ?oc=5

## 오늘 주요 토픽
- 일반: 기사 수 177건, 점수 합계 293.98, 버스트 상
- 주식시장: 기사 수 32건, 점수 합계 78.72, 버스트 하
- 정책/규제: 기사 수 17건, 점수 합계 39.2, 버스트 하

## 급증 토픽
- 일반: 버스트 상

## 체크 변수
- 한국 기준금리: 25.08 (기준일 2026-03-01)
- 미국 CPI 3개월 변화: 데이터 부족
- 원/달러 5일 변화: +2.5% (최근 5구간, 기준일 2026-03-04)
- 원/달러 z-score(60): +1.68σ (등급 중, 기준일 2026-03-04)
- 광의통화(M2) z-score(12): +1.59σ (등급 중, 기준일 2026-03-01)

## Top Items
- [5.98] 주식시장 | 미래에셋생명, 자사주 93% 소각…"주주가치 제고" | https://www.yna.co.kr/view/AKR20260304166800002 | 최근성 반영 + 소스 신뢰도 반영 + 키워드 일치 반영
- [3.78] 일반 | 與, 내일 재계와 간담회…중동 정세·대미관세 협상 의견청취(종합) | https://www.yna.co.kr/view/AKR20260304167351001 | 최근성 반영 + 소스 신뢰도 반영
- [3.78] 일반 | 환갑 맞은 국세청, 'K-AI 대전환' 60대 미래혁신안 발표 | https://www.yna.co.kr/view/AKR20260304149800002 | 최근성 반영 + 소스 신뢰도 반영
- [3.72] 일반 | [단독] '국민연금 관치' 벗나…130조 의결권 민간에 넘긴다 | https://www.hankyung.com/article/2026030491721 | 최근성 반영 + 소스 신뢰도 반영
- [3.45] 일반 | 롯데손보 ‘경영개선요구’ 의결…2개월 내 자본확충 계획 제출 - 한겨레 | https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBydEJoYVBHeDFhLVcxZG00NjJVdGJXbUJobWd6X0tidktfVk9mVWljeDdPaGZyZV9VamhZVThIcFV0eFo0aHNJQWpULXF4Vy1lcEY3VnAzaFpvWDFielkyNTl6MWlfVzQ?oc=5 | 최근성 반영 + 소스 신뢰도 반영
- [2.98] 주식시장 | 코스피 하락률, 9.11 테러 때보다 높았다…불명예 기록도 속출 | https://www.yna.co.kr/view/AKR20260304152900008 | 최근성 반영 + 소스 신뢰도 반영 + 키워드 일치 반영
- [2.98] 환율 | 중동 전쟁 파장에…원/달러 환율 10.1원 뛴 1,476.2원 | https://www.yna.co.kr/view/AKR20260304145100002 | 최근성 반영 + 소스 신뢰도 반영 + 키워드 일치 반영
- [2.98] 주식시장 | 올해 상승률 세계 1위 코스피, 중동 사태 충격파도 가장 컸다(종합) | https://www.yna.co.kr/view/AKR20260304070751008 | 최근성 반영 + 소스 신뢰도 반영 + 키워드 일치 반영
- [2.98] 주식시장 | '공포의 수요일' 코스피, 12% 폭락해 5,090대…역대 최대 하락률 | https://www.yna.co.kr/view/AKR20260304137100008 | 최근성 반영 + 소스 신뢰도 반영 + 키워드 일치 반영
- [2.93] 주식시장 | '이란 사태'로 암초 부닥친 韓증시…전문가들 "패닉은 금물"(종합) | https://www.yna.co.kr/view/AKR20260304063851008 | 최근성 반영 + 소스 신뢰도 반영 + 키워드 일치 반영
