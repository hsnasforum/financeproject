# News Daily Brief

## 요약
- Generated at: 2026-03-04T11:27:31.261Z
- Stats: items=309, clusters=302, deduped=0, feeds=7
- Observation: 주식시장 관련 이슈 비중이 높아졌고, 관찰 우선순위가 상승했습니다.

## 근거 링크 (2~5)
- https://www.yna.co.kr/view/AKR20260304166800002
- https://www.yna.co.kr/view/AKR20260304167351001
- https://www.yna.co.kr/view/AKR20260304149800002
- https://www.hankyung.com/article/2026030491721
- https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBydEJoYVBHeDFhLVcxZG00NjJVdGJXbUJobWd6X0tidktfVk9mVWljeDdPaGZyZV9VamhZVThIcFV0eFo0aHNJQWpULXF4Vy1lcEY3VnAzaFpvWDFielkyNTl6MWlfVzQ?oc=5

## 체크 변수
- 일반 기사량(전일 대비)
- 정책금리
- 원/달러 환율
- 브렌트유

## 반대 시그널
- 핵심 토픽 기사량 증가세 둔화
- 주요 지표 변동성 축소
- 상반 신호 기사 비중 증가

## 오늘의 Top N
- [5.98] 주식시장 | 미래에셋생명, 자사주 93% 소각…"주주가치 제고" | https://www.yna.co.kr/view/AKR20260304166800002
- [3.78] 일반 | 與, 내일 재계와 간담회…중동 정세·대미관세 협상 의견청취(종합) | https://www.yna.co.kr/view/AKR20260304167351001
- [3.78] 일반 | 환갑 맞은 국세청, 'K-AI 대전환' 60대 미래혁신안 발표 | https://www.yna.co.kr/view/AKR20260304149800002
- [3.72] 일반 | [단독] '국민연금 관치' 벗나…130조 의결권 민간에 넘긴다 | https://www.hankyung.com/article/2026030491721
- [3.45] 일반 | 롯데손보 ‘경영개선요구’ 의결…2개월 내 자본확충 계획 제출 - 한겨레 | https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBydEJoYVBHeDFhLVcxZG00NjJVdGJXbUJobWd6X0tidktfVk9mVWljeDdPaGZyZV9VamhZVThIcFV0eFo0aHNJQWpULXF4Vy1lcEY3VnAzaFpvWDFielkyNTl6MWlfVzQ?oc=5
- [2.98] 주식시장 | 코스피 하락률, 9.11 테러 때보다 높았다…불명예 기록도 속출 | https://www.yna.co.kr/view/AKR20260304152900008
- [2.98] 환율 | 중동 전쟁 파장에…원/달러 환율 10.1원 뛴 1,476.2원 | https://www.yna.co.kr/view/AKR20260304145100002
- [2.98] 주식시장 | 올해 상승률 세계 1위 코스피, 중동 사태 충격파도 가장 컸다(종합) | https://www.yna.co.kr/view/AKR20260304070751008
- [2.98] 주식시장 | '공포의 수요일' 코스피, 12% 폭락해 5,090대…역대 최대 하락률 | https://www.yna.co.kr/view/AKR20260304137100008
- [2.93] 주식시장 | '이란 사태'로 암초 부닥친 韓증시…전문가들 "패닉은 금물"(종합) | https://www.yna.co.kr/view/AKR20260304063851008

## 토픽별 Top M
- 주식시장
  - [5.98] 미래에셋생명, 자사주 93% 소각…"주주가치 제고" | https://www.yna.co.kr/view/AKR20260304166800002
  - [2.98] 코스피 하락률, 9.11 테러 때보다 높았다…불명예 기록도 속출 | https://www.yna.co.kr/view/AKR20260304152900008
  - [2.98] 올해 상승률 세계 1위 코스피, 중동 사태 충격파도 가장 컸다(종합) | https://www.yna.co.kr/view/AKR20260304070751008
- 일반
  - [3.78] 與, 내일 재계와 간담회…중동 정세·대미관세 협상 의견청취(종합) | https://www.yna.co.kr/view/AKR20260304167351001
  - [3.78] 환갑 맞은 국세청, 'K-AI 대전환' 60대 미래혁신안 발표 | https://www.yna.co.kr/view/AKR20260304149800002
  - [3.72] [단독] '국민연금 관치' 벗나…130조 의결권 민간에 넘긴다 | https://www.hankyung.com/article/2026030491721
- 환율
  - [2.98] 중동 전쟁 파장에…원/달러 환율 10.1원 뛴 1,476.2원 | https://www.yna.co.kr/view/AKR20260304145100002
  - [2.42] 환율 다시 뛰는데…국회서 발 묶인 '국장 복귀계좌' | https://www.hankyung.com/article/2026030492441
- 정책/규제
  - [2.69] 내일 금융위 당정협의 전격 순연…‘중동·이란 사태’ 대책회의 여파 | https://www.mk.co.kr/news/stock/11978847
  - [2.62] [단독] 1주택자 전세대출 보증 조인다…‘비거주 1주택자’ 규제 강화 | https://www.mk.co.kr/news/economy/11978848
  - [2.59] 상상인그룹 "9년째 휠체어 기부…정부 정책화 결실" | https://www.hankyung.com/article/2026030478751
- 금리
  - [2.48] 중동발 쇼크에 '안전자산' 채권도 속수무책…금리 연일 오름세 | https://www.yna.co.kr/view/AKR20260304153500008
  - [2.48] 국고채 금리, 중동 전쟁에 이틀째 상승…3년물 연 3.223%(종합) | https://www.yna.co.kr/view/AKR20260304152051008
  - [2.48] 국고채 금리 혼조세…3년물 연 3.223% | https://www.yna.co.kr/view/AKR20260304152000008
- 유가
  - [2.32] 한국증시 사상최대 폭락…9·11때보다 더 큰 충격 빠졌다 | https://www.mk.co.kr/news/stock/11978860
  - [2.32] 장금상선, 유조선에 3조원 선제적 베팅 | https://www.mk.co.kr/news/business/11978764
  - [2.25] 외국인 증시 이탈·유가 급등·원유 의존도에 환율 한때 1500원 - 한겨레 | https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBSM2xNelJhUU54VlpnNGNtZTNRYWcweXIyTlBpN3doVHRJTzZxdExBRkFSWGx2aVRRd0x2bUl2MU4tRlg4U2FxemhBQWVTX19yMF9mTnZ6bXV5dVlVYW9Ddk1QVnBXRVU?oc=5

## 증가 토픽
- 일반: 오늘 기사 수 177건, 전일 기사 수 24건, 증감 153건, 증가 배율 7.38배
- 주식시장: 오늘 기사 수 32건, 전일 기사 수 0건, 증감 32건, 증가 배율 999배
- 정책/규제: 오늘 기사 수 17건, 전일 기사 수 0건, 증감 17건, 증가 배율 999배
- 금리: 오늘 기사 수 9건, 전일 기사 수 1건, 증감 8건, 증가 배율 9배
- 유가: 오늘 기사 수 6건, 전일 기사 수 0건, 증감 6건, 증가 배율 999배
- 환율: 오늘 기사 수 2건, 전일 기사 수 0건, 증감 2건, 증가 배율 999배
