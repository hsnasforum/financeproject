# Planning v2 Ops Dashboard

## 개요
- 통합 운영 페이지: `/ops/planning`
- 목적: assumptions / regression / cache / store 상태를 한 화면에서 확인하고 필요한 운영 액션을 실행

## Planning 백업 포함 정책
- A. 필수(재현성/사용자 데이터, export/import/restore point에서 항상 포함 대상)
  - `.data/planning/assumptions.latest.json`
  - `.data/planning/assumptions/history/*.json`
  - `.data/planning/profiles/*.json`
  - `.data/planning/runs/*.json`
- B. 선택(성능/진단, 누락되어도 복구 가능)
  - `.data/planning/cache/*.json`
  - `.data/planning/eval/latest.json`
  - `.data/planning/eval/history/*.json`
- Import/Restore는 A 경로를 우선 복원 대상으로 보고, B 경로는 있으면 함께 복원합니다.

## 화면 섹션
1. Assumptions Snapshot Status
   - latest snapshot id/asOf/fetchedAt/missing/warnings/sources
   - staleDays(45일 warn, 120일 critical)
   - 주요 금리/물가 지표 + history count
   - `Sync snapshot now` 버튼(기존 `/api/ops/assumptions/sync` 재사용)
   - 상세 작업: `/ops/assumptions`, `/ops/assumptions/history`
   - 롤백(set latest): history 화면에서 `SET_LATEST {snapshotId}` confirm 필요
2. Regression Status
   - `.data/planning/eval/latest.json` 기반 pass/fail 요약
   - 실패 상위 5개 케이스 요약
   - `Copy CLI command`로 `pnpm planning:v2:regress` 복사
   - 상세 리포트: `/ops/planning-eval`
3. Cache Status
   - planning cache total/byKind + hitRate
   - `Purge expired` 버튼(기존 `/api/ops/planning-cache/purge` 재사용)
   - 상세 페이지: `/ops/planning-cache`
4. Store Status
   - profile/run 레코드 개수
   - profiles+runs 디렉토리 기준 대략 용량
   - `Run Planning Doctor`로 무결성 검사 실행 (strict 옵션 지원)

## 보안/운영 가드
- Sync/Purge는 기존 route의 local-only + same-origin + dev unlock + csrf 가드를 그대로 사용합니다.
- purge 실행 시 audit log 이벤트 `PLANNING_CACHE_PURGE`가 기록됩니다.

## 자동 운영(Ops Run)
- 스케줄러 복붙 템플릿: [planning-v2-scheduler.md](./planning-v2-scheduler.md)
- Daily 운영:
  - `pnpm planning:v2:ops:run`
  - 기본 순서: doctor -> 조건부 assumptions sync -> complete
  - regress는 기본 비활성(시간 절약)
- 주간/업데이트 후 운영:
  - `pnpm planning:v2:ops:run:regress`
- 보관 정책 정리:
  - `pnpm planning:v2:ops:prune -- --keep=50`
- 조건부 스냅샷 동기화:
  - snapshot 없음 또는 `fetchedAt` 기준 45일 초과 시에만 `planning:assumptions:sync` 시도
  - sync 실패는 WARN으로 기록하고 complete 게이트는 계속 진행
- 실행 리포트/로그:
  - `.data/planning/ops/reports/{YYYYMMDD-HHmmss}.json`
  - `.data/planning/ops/logs/{YYYYMMDD-HHmmss}.log`

## Planning Cleanup (Retention)
- 화면: `/ops/planning-cleanup`
- 기본 정책:
  - `runs.keepPerProfile=50`
  - `cache.keepDays=7`
  - `opsReports.keepCount=50`
  - `assumptionsHistory.keepCount=200`
- 절차:
  1. target 선택
  2. `Dry Run` 실행(삭제 예정 건수/용량/샘플 확인)
  3. 확인 문구 `CLEANUP {target} {deleteCount}` 입력
  4. `Apply` 실행
- 보안:
  - local-only + same-origin + dev unlock + csrf 검증
  - dry-run/apply 모두 audit log 이벤트 기록
- 주의:
  - 적용 후 되돌릴 수 없습니다.
  - 정리 전 backup/export를 권장합니다.

### 스케줄러에 붙이는 방법(예시, Asia/Seoul)
- Windows 작업 스케줄러:
  - Program/script: `cmd.exe`
  - Add arguments: `/c cd /d C:\path\to\finance && pnpm planning:v2:ops:run`
  - Trigger: 매주 1회(또는 매월 1회), 시간대 `Korea Standard Time`
- macOS launchd(명령 예시):
  - `cd /path/to/finance && pnpm planning:v2:ops:run`
- Linux cron(명령 예시):
  - `CRON_TZ=Asia/Seoul`
  - `0 9 * * 1 cd /path/to/finance && pnpm planning:v2:ops:run >> .data/planning/ops/cron.log 2>&1`

## 운영 런북

### 1) Snapshot 동기화/롤백
1. `/ops/assumptions`에서 `Sync now` 실행
2. 경고가 있으면 `warnings`와 source를 확인
3. 문제 발생 시 `/ops/assumptions/history`에서 이전 snapshot을 선택 후 `Set as latest`
   - confirm 문자열 필요

### 2) Regression 점검
1. `pnpm planning:v2:regress` 실행
2. `/ops/planning` 또는 `/ops/planning-eval`에서 FAIL 케이스 확인
3. 원칙: 코드 수정 없이 baseline 자동 업데이트 금지
4. 수정 후 다시 regress 실행

### 2-1) 보안/누출 가드 점검
1. `pnpm planning:v2:guard` 실행
2. client 코드의 민감 env 참조/내부 경로 문자열 노출 여부를 확인
3. planning API 응답 코드에서 `sources.url`/`.data` 패턴이 감지되면 수정 후 재실행

### 3) Cache 운영
1. `/ops/planning` 또는 `/ops/planning-cache`에서 entry/hitRate 확인
2. 폭증/오염 의심 시 `Purge expired` 실행
3. 필요 시 retention/캐시 정책 점검

### 4) Backup/Import/Restore
1. `/settings/backup`에서 export/import 실행
2. Import 후 `/ops/planning`에서 Planning Doctor 실행
3. 문제 시 restore point rollback 실행 후 doctor 재확인

### 5) 업데이트/복구 절차 (고정)
1. 업데이트 전:
   - export/restore point 생성
   - `pnpm planning:v2:complete` 통과 확인
2. 업데이트 후:
   - `pnpm planning:v2:regress` 실행
   - FAIL 시 baseline 자동 갱신 금지, 원인 수정 또는 롤백
3. 문제 발생 시:
   - restore point apply
   - `/ops/assumptions/history`에서 snapshot latest 롤백
   - `pnpm planning:v2:ops:prune` 또는 `/ops/planning-cache` purge 실행

## Import/Restore 후 무결성 확인
1. `/ops/planning`의 `Run Planning Doctor` 실행
2. `missing / invalidJson / optionalMissing` 항목 확인
3. 필요 시 strict 모드로 다시 실행하거나, CLI에서 `pnpm planning:v2:doctor -- --strict` 실행

## 사고 대응 가이드
- 스냅샷 파싱/ECOS 실패:
  - assumptions warnings 확인
  - fallback 동작 여부 확인
  - 필요 시 수동으로 이전 snapshot을 latest로 롤백
- ops run에서 snapshot sync 실패:
  - 리포트의 `snapshot.syncResult`/steps note 확인
  - 기존 latest snapshot 유지 상태에서 complete 결과를 우선 확인
- regression FAIL:
  - baseline 업데이트 전에 반드시 diff 원인 분석
  - 의도치 않은 변경이면 코드 롤백/수정
- complete FAIL:
  - report steps에서 실패한 게이트(`guard`/`smoke`/`test` 등) 확인 후 수정
- cache 급증:
  - purge 후 재측정
  - 반복 발생 시 호출 패턴/TTL/옵션 키 확인

## 감사로그 이벤트
- `BACKUP_EXPORT`
- `BACKUP_IMPORT`
- `RESTORE_POINT_CREATE`
- `RESTORE_POINT_APPLY`
- `PLANNING_DOCTOR_RUN`
